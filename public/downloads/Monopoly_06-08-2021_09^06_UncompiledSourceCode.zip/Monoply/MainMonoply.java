import java.io.*;
import java.util.*;

public class MainMonoply {
	public static boolean debugRun = false;//DO NOT ENABLE
	
	
	public static void main(String args[]) {
		System.out.println("TEST");
		System.out.println(UI._GREEN + "");

		Property[] propertiesArray = new Property[40];

//		Chosen SETTINGS
		double _startingFunds = 0;

		char[][][] _gameBoard = UI.setupBoard();// Just calls Creation
		Cards _cards = new Cards();

		propertiesArray = generatePropertes(propertiesArray);

		if (UI.displayScreen(" -- Game Options -- ", new String[] { "Two Player", "Quit" }, false)
				.equals("Two Player")) {
		} else {
			return;
		}

		String selectedOption = UI.displayScreen(" -- Staring Money ($1,500)-- ",
				new String[] { "Standard", "-Half ($750)", "+Half ($2,250)" }, false);
//        TODO: I can make this better
		if (selectedOption.equals("Standard")) {
			_startingFunds = 1_500.00;
		} else if (selectedOption.equals("-Half ($750)")) {
			_startingFunds = 750.00;
		} else if (selectedOption.equals("+Half ($2,250)")) {
			_startingFunds = 2_250.00;
		}

		int selectedPos = Integer.parseInt(UI.displayScreen(" -- Player1's Piece Color -- ",
				new String[] { "Red", "Green", "Yellow", "Blue", "Purple", "Cyan" }, true)) - 1;
		String player1Color, player2Color;
		if (selectedPos == 0)
			player1Color = UI._RED;
		else if (selectedPos == 1)
			player1Color = UI._GREEN;
		else if (selectedPos == 2)
			player1Color = UI._YELLOW;
		else if (selectedPos == 3)
			player1Color = UI._BLUE;
		else if (selectedPos == 4)
			player1Color = UI._PURPLE;
		else if (selectedPos == 5)
			player1Color = UI._CYAN;
		else// This should never run
			player1Color = UI._BLACK;

		selectedPos = Integer.parseInt(UI.displayScreen(" -- Player2's Piece Color -- ",
				new String[] { "Red", "Green", "Yellow", "Blue", "Purple", "Cyan" }, true)) - 1;
		if (selectedPos == 0)
			player2Color = UI._RED;
		else if (selectedPos == 1)
			player2Color = UI._GREEN;
		else if (selectedPos == 2)
			player2Color = UI._YELLOW;
		else if (selectedPos == 3)
			player2Color = UI._BLUE;
		else if (selectedPos == 4)
			player2Color = UI._PURPLE;
		else if (selectedPos == 5)
			player2Color = UI._CYAN;
		else// This should never run
			player2Color = UI._BLACK;

//        GO$ as well
//DISPLAY WHAT HAS BEEN SELECTED
		UI.clear();
		System.out.println("# Of Players: " + "2" + "\n" + "Starting $: " + _startingFunds + "\n"
//			"Somethign else here: "+""+"\n"
		);

//		Player player1 = new Player('1',"PlayerOne'sName", 'A', UI.__WHITE+player1Color+UI._CLEAR, _startingFunds,"S00");
//		Player player2 = new Player('2',"PlayerTwo'sName", '&', UI.__WHITE+player2Color+UI._CLEAR, _startingFunds,"S01");
		UI.clear();
		Player player1 = new Player('1', UI.getTypedStr("Player 1 please enter your name and then press enter: "),
				UI.getTypedChr("Player 1 please enter a character and then press enter: "), UI.__WHITE + player1Color,
				_startingFunds, "S00");
		Player player2 = new Player('2', UI.getTypedStr("Player 2 please enter your name and then press enter: "),
				UI.getTypedChr("Player 1 please enter a character and then press enter: "), UI.__WHITE + player2Color,
				_startingFunds, "S01");

		String _stringBoardMaster = UI.makeBoardStr(_gameBoard);
		String _stringBoardNewly;

		System.out.println(_stringBoardMaster);
//I can optimize but for changing views it will be much easier to just rerun.
//		TODO: Switch to indexOfSystem with some other things if going for increased speed.

		boolean firstPlayersTurn = true;// Could tie to move number but will keep it open in case they need to be
										// decoupled
		int turnNum = 0;
		Player player;
		int winner = 0;
		int dice1 = -1;
		int dice2 = -1;
		int spacesToMove = -1;
		int newLocation = -1;
		Property oldLocation;
		Property landedOn;
		String owner = "<Owner>";
		double startingBalance = 0.0;
		String landedOnStr;
		double spend;

		System.out.println(UI._BOLD + "BOLD" + UI._CLEAR);
		System.out.println(UI._UNDERLINE + "UNDERLINE" + UI._UNDERLINE);
//		System.out.println("\u001B[5m"+"other"+UI._CLEAR);
		System.out.println(UI.__RED + " TESTING " + "" + UI._CLEAR);

		do {
			spend = 0;
			if (firstPlayersTurn) {
				player = player1;
			} else {
				player = player2;
			}
			firstPlayersTurn = !firstPlayersTurn;

//			OLD's
			int gatheredPosition = Integer.parseInt(player.getLocation().substring(1, 3));
//			System.out.println("gatheredPosition = " + gatheredPosition);
			if (gatheredPosition == 96 || gatheredPosition == 97) {
				oldLocation = propertiesArray[10];
//				if(gatheredPosition == 96)
//					gatheredPosition = 20;
//				else
//					gatheredPosition = 21;
			} else {
				oldLocation = propertiesArray[Integer.parseInt(player.getLocation().substring(1, 3)) / 2];// TODO: Make
																											// method
			}

			startingBalance = player.getBalance();

			_stringBoardNewly = _stringBoardMaster.replace(player1.getLocation(),
					player1.getColor() + "<" + "<PLAYER1C>" + UI._CLEAR + player1.getColor() + ">" + UI._CLEAR);
			_stringBoardNewly = _stringBoardNewly.replace(player2.getLocation(),
					player2.getColor() + "<" + "<PLAYER2C>" + UI._CLEAR + player2.getColor() + ">" + UI._CLEAR);

			// Lambda
			myInterface infoAndBoard = (Player player_, String stringBoardNewly_, Property[] propertiesArray_,
					Player player1_, Player player2_) -> {
				UI.clear();
				System.out.println(UI._UNDERLINE + "Turn Info: " + player_.getColor() + player_.getName() + UI._CLEAR
						+ UI._UNDERLINE + "'s turn." + UI._CLEAR);
				
				System.out.print(UI.prettyify(stringBoardNewly_).replace("<PLAYER1C>", player1_.getCharacter()).replace("<PLAYER2C>", player2_.getCharacter()));
				// Print property total box.
				System.out.println(UI.propertyLine(player1_, propertiesArray_));
				System.out.println(UI.propertyLine(player2_, propertiesArray_));
			};
			infoAndBoard.run(player, _stringBoardNewly, propertiesArray, player1, player2);

			char dontKnowWhyINeedThis = UI.getTypedChr("Press enter to roll the dice: ");

			dice1 = Creation.generateDiceRoll(6);
			dice2 = Creation.generateDiceRoll(6);
	        System.out.println("Enter the ammount to move: ");
//	        dice1 = Integer.parseInt(UI.getTypedStr());
//	        dice2 = 0;
			spacesToMove = dice1 + dice2;
//	        newLocation = gatheredPosition;//Integer.parseInt(player.getLocation().substring(1,3));
			newLocation = Integer.parseInt(player.getLocation().substring(1, 3));

			newLocation += (newLocation!=96)? (spacesToMove * 2): 0;

			String printout = "";
			if (newLocation == 96) {
				printout+="You have been released from JAIL, you are now in the visitor section.\n";
				newLocation = 20;
			} else if (newLocation == 97) {
				printout+=("You have been released from JAIL, you are now in the visitor section.\n");
				newLocation = 21;
			} else if (newLocation > 79) {
				newLocation -= 79;
				printout+=("You passed " + UI._RED + "GO" + UI._CLEAR + ", you gain $200.\n");
				spend -= 200;
			}

//        	if(newLocation==96 || newLocation==97) {//Can be set to range if nessery

			landedOn = propertiesArray[newLocation / 2];
			if (newLocation == 61 || newLocation == 60) {
				printout+=("You went directly to jail, you did not pass GO, you have been fined $100.\n");
				if (newLocation == 60)
					newLocation = 96;
				else
					newLocation = 97;
			}
			player.setLocation("S" + (newLocation < 10 ? "0" : "") + newLocation);

//        	Display new board
			_stringBoardNewly = _stringBoardMaster.replace(player1.getLocation(),
					player1.getColor() + "<" + "<PLAYER1C>" + ">" + UI._CLEAR);
			_stringBoardNewly = _stringBoardNewly.replace(player2.getLocation(),
					player2.getColor() + "<" + "<PLAYER2C>" + ">" + UI._CLEAR);
			

//	        SPECIAL AREAS CHECK
			landedOnStr = UI.__BLACK + UI.getFC(landedOn.color()) + landedOn.name() + UI._CLEAR;
        	owner = landedOn.owner()=='1' ? player1.getColor()+player1.getName()+UI._CLEAR : player2.getColor()+player2.getName()+UI._CLEAR;//TODO: Switch to array
			// TODO: Switch to array or at least a case

			System.out.print(printout);
			if (landedOn.owner() == player.getId())
				owner = player.getColor() + "YOU (" + player.getName() + ")" + UI._CLEAR;
			else if (landedOn.owner() == '1')
				owner = player1.getColor() + player1.getName() + UI._CLEAR;
			else if (landedOn.owner() == '2')
				owner = player2.getColor() + player2.getName() + UI._CLEAR;
			else
				owner = "The Bank";


			infoAndBoard.run(player, _stringBoardNewly, propertiesArray, player1, player2);

			System.out.println(
					player.getColor() + player.getName() + UI._CLEAR + " rolled a " + dice1 + " and a " + dice2 + ".");
			System.out.println("Because of this you move " + spacesToMove + " spaces and land on " + landedOnStr + ". ("
					+ player.getLocation() + ")");
//        	if(landedOn.owner() != '0'){

			if (landedOn.owner() != '0') {
				System.out.println("The owner of that property is " + owner
						+ (landedOn.owner() == 'b' ? ", you could buy it from them for $" + landedOn.price() : "")
						+ ".");
			} else if (landedOn.chance()) {
				_cards.pickupCard();
				_cards.lastDisplay();
				System.out.println("Because you landed on a " + landedOnStr + " you pulled a card from the "
						+ landedOnStr + " pile which was \"" + _cards.lastDescription() + "\"");
				System.out.println(
						"You " + (_cards.lastPrice() > 0 ? "gain" : "loose") + " $" + Math.abs(_cards.lastPrice()));
				spend -= _cards.lastPrice();

			}
			if (landedOn.owner() == player1.getId() && (player1 != player)) {// I finally had a use for this! :)
				player1.addBalance(landedOn.rent());
			} else if (landedOn.owner() == player2.getId() && (player2 != player)) {// I finally had a use for this! :)
				player2.addBalance(landedOn.rent());
			}

			spend += !(landedOn.owner() == 'b' || landedOn.owner() == player.getId()) ? landedOn.rent() : 0.0;


			if (landedOn.owner() == 'b' && player.getBalance() >= landedOn.price()) {
				System.out.print("To purchase " + landedOnStr + " type 'p' and then enter (your balance is $"+player.getBalance()+"): ");
				if (Character.toLowerCase(UI.getTypedStr().charAt(0)) == 'p') {
					spend += landedOn.price();
					landedOn.owner(player.getId());
					System.out.println("Purchased! You now own " + landedOnStr + ", rent is $" + landedOn.rent() + "");
				}
			}
			player.subtractBalance(spend);
			System.out.println("---------------------------\n" + "You started at " + UI.__BLACK
					+ UI.getFC(oldLocation.color()) + oldLocation.name() + UI._CLEAR + " and ended on " + landedOnStr
					+ " where you " + ((spend < 0) ? "earned" : "spent") + " $" + Math.abs(spend) + "\n"
					+ "Your balance was $" + startingBalance + " and now is $" + player.getBalance() + "\n"
//        		+"Your options: "
			);
			
//        	 the output should state the starting position, the bankroll of the player, the roll of the die, the ending position, who the property is owned by, money gained or lost by the move, and the ending bank balance.

			System.out.println("This concludes turn #" + turnNum++ + ".");

			System.out.print("Press enter to switch player: ");
			String userInp = UI.getTypedChr()+"";
			if (userInp.equals("q") || player.getBalance() < 0) {
				System.out.println(player.getColor() + "You" + UI._CLEAR
						+ " do not have sufficient funds. Good luck next time you play Monopoly!");

				return;
			}
			turnNum++;
//		} while (turnNum < 500);
		} while (winner == 0);

	}

	interface myInterface {
		void run(Player player_, String stringBoardNewly_, Property[] propertiesArray_, Player player1_,
				Player player2_);
	}

	private static Property[] generatePropertes(Property[] propertiesArray_) {

//String name_,char owner_,char color_,double purchaseCost_,double rentCost_,boolean isRailroad_,boolean isChance_

		/*
		 * OWNERS 0 = Reserved for unpurchasable b = Bank 1 = User#1 2 = User#2
		 */
		int i = 0;

//		\001b[38;2;r;g;bm
//							name,owner,color,purchaseCost,rentCost,isRailroad,isChance
//		SHOULD HAVE HAD IT WITH MORE OVERLOADED CONSTRUCTORS OR A .set___() for after
		propertiesArray_[i++] = new Property("Go", '0', 'r', 0, -200, false, false);

		propertiesArray_[i++] = new Property("Mediterranean Avenue", 'b', 'W', 60, 4, false, false);
		propertiesArray_[i++] = new Property("Community Chest", '0', 'W', 0, 0, false, true);// Chest
		propertiesArray_[i++] = new Property("Baltic Avenue", 'b', 'W', 60, 4, false, false);

		/* Income tax */ propertiesArray_[i++] = new Property("Income Tax", '0', 'W', 60, 200, false, false);// TODO:
																												// Compute
																												// total
																												// value
		propertiesArray_[i++] = new Property("Reading Railroad", 'b', 'w', 0, 50, true, false);
		propertiesArray_[i++] = new Property("Oriental Avenue", 'b', 'c', 100, 6, false, false);
		propertiesArray_[i++] = new Property("Chance", '0', 'W', 0, 0, false, true);// CHANCE
		propertiesArray_[i++] = new Property("Vermont Avenue", 'b', 'c', 100, 6, false, false);

		propertiesArray_[i++] = new Property("Connecticut Avenue", 'b', 'c', 120, 6, false, false);
		propertiesArray_[i++] = new Property("Visiting JAIL", '0', 'W', 0, 0, false, false);

		propertiesArray_[i++] = new Property("St. Charles Place", 'b', 'p', 140, 10, false, false);

		propertiesArray_[i++] = new Property("Electric Company", 'b', 'W', 150, 50, false, false);

		propertiesArray_[i++] = new Property("States Avenue", 'b', 'p', 140, 10, false, false);
		propertiesArray_[i++] = new Property("Virginia Avenue", 'b', 'p', 160, 12, false, false);

		propertiesArray_[i++] = new Property("Pennsylvania Railroad", 'b', 'W', 200, 50, true, false);

		propertiesArray_[i++] = new Property("St. James Place", 'b', 'o', 180, 14, false, false);
		propertiesArray_[i++] = new Property("Community Chest", '0', 'W', 0, 0, false, true);// Chest
		propertiesArray_[i++] = new Property("Tennessee Avenue", 'b', 'o', 180, 14, false, false);
		propertiesArray_[i++] = new Property("New York Avenue", 'b', 'o', 200, 16, false, false);
		propertiesArray_[i++] = new Property("Free Parking", '0', 'W', 0, 0, false, false);
		propertiesArray_[i++] = new Property("Kentucky Avenue", 'b', 'r', 220, 18, false, false);
		propertiesArray_[i++] = new Property("Chance", '0', 'W', 0, 0, false, true);// Chance
		propertiesArray_[i++] = new Property("Indiana Avenue", 'b', 'r', 220, 18, false, false);
		propertiesArray_[i++] = new Property("Illionois Avenue", 'b', 'r', 240, 20, false, false);

		propertiesArray_[i++] = new Property("B. & O. Railroad", 'b', 'W', 200, 50, true, false);

		propertiesArray_[i++] = new Property("Atlantic Avenue", 'b', 'y', 260, 22, false, false);
		propertiesArray_[i++] = new Property("Ventor Avenue", 'b', 'y', 260, 22, false, false);
		propertiesArray_[i++] = new Property("Water Works", 'b', 'W', 150, 50, false, false);
		propertiesArray_[i++] = new Property("Marvin Gardens", 'b', 'y', 260, 22, false, false);

		propertiesArray_[i++] = new Property("Go To Jail", '0', 'W', 0, 100, false, false);

		propertiesArray_[i++] = new Property("Pacific Avenue", 'b', 'g', 300, 26, false, false);
		propertiesArray_[i++] = new Property("North Carolina Avenue", 'b', 'g', 320, 26, false, false);
		propertiesArray_[i++] = new Property("Community Chest", '0', 'W', 0, 0, false, true);// Chest
		propertiesArray_[i++] = new Property("Pennsylvania Avenue", 'b', 'g', 320, 28, false, false);

		propertiesArray_[i++] = new Property("Short Line Railroad", 'b', 'W', 200, 50, true, false);
		propertiesArray_[i++] = new Property("Chance", '0', 'W', 0, 0, false, true);// Chance

		propertiesArray_[i++] = new Property("Park Place", 'b', 'b', 350, 35, false, false);
		propertiesArray_[i++] = new Property("Luxury Tax", '0', 'W', 0, 75, false, false);
		propertiesArray_[i++] = new Property("Boardwalk", 'b', 'b', 400, 50, false, false);

		return propertiesArray_;
	}

}