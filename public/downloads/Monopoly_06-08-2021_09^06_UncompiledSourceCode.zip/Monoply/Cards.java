public class Cards{
	
	int _lastPosition = 0;
							//     Pos  0=Description, 1=Display, 2=price
//	String[][]_cardsList = new String[20][3];
	String[][]_cardsList;
	
	public Cards(){
		_cardsList = new String[][]{
			{"Insurance Cost Raised","---","-200"},
			{"Tax audit","---","-150"},
			{"Medial emergency","---","-300"},
			
			{"Removed employee benfits","---","+300"},
			{"Offshore bank","---","+200"},
			{"Liquadation sale","---","+150"}

		};
	}
	
	
	public int pickupCard() {
//		Does not need seed system
		_lastPosition = Creation.generateDiceRoll(_cardsList.length)-1;
		return _lastPosition;
	}
	
	
	public String lastDescription() {return _cardsList[_lastPosition][0];}
	
	public String lastDisplay() {return _cardsList[_lastPosition][1];}
	
	public double lastPrice() {
		return Double.parseDouble(_cardsList[_lastPosition][2]);
	}
}
