import java.util.ArrayList;

public class Player{
	
	private char id = '\0';
	private String name = "<name>";
	private char ownerChar = '\0';
	private String color = UI._WHITE;
	private double balance = 0;
	private String position = "S00";

	ArrayList<Integer> ownedProperties= new ArrayList<Integer>(); // Create an ArrayList object

	public Player(char id_, String name_, char ownerChar_, String color_, double balance_, String position_) {
		id = id_;
		name = name_;
		ownerChar = ownerChar_;
		color = color_;
		balance = balance_;
		position = position_;
	}
	
	public char getId()                 { return id;}
	public String getLocation()         { return position;}
	public void setLocation(String pos_){ position = pos_;}//SETTER\\
	public String getColor()            { return color;}
	public String getCharacter()        { return ""+ownerChar;}
	public String getName()             { return name;}
	public double getBalance()          { return balance;}
	public double addBalance(double ba_){ balance += ba_; return balance;}
	public void subtractBalance(double p){ balance -= p;}
	
	
	public void addProperty(int boardPosition_) { ownedProperties.add(boardPosition_); }
	
	public boolean removeProperty(int boardPosition_) {
		for(int i=0; i<ownedProperties.size(); i++) {
			if(ownedProperties.get(i) == boardPosition_) {
				ownedProperties.remove(i);
				return true;
			}
		}
		return false;
	}
	

	
}