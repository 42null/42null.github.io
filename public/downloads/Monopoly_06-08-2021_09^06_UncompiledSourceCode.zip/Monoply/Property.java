public class Property{
	
	private String name = "<name>";
	private char owner = '0';
	private char color = '\0';
	private double cost = -1;
	private double rent = -1;
	private boolean railroad = false;
	private boolean chance = false;
	
	
	public Property(String name_, char owner_, char color_, double purchaseCost_, double rentCost_, boolean isRailroad_, boolean isChance_) {
		name = name_;
		owner = owner_;
		color = color_;
		cost = purchaseCost_;
		rent = rentCost_;
		railroad = isRailroad_;
		chance = isChance_;
	}
	
	public String name()      { return name; }
	public char owner()       { return owner; }
	public void owner(char o_){ owner = o_; }
	public char color()       { return color; }
	public double price()     { return cost; }
	public double rent()      { return rent; }
	public boolean railroad() { return railroad; }
	public boolean chance()   { return chance; }
	
}