import java.io.IOException;
import java.util.Scanner;

public class UI{
    public static final String _CLEAR = "\u001B[0m";
    public static final String _BLACK = "\u001B[30m";
    public static final String _RED = "\u001B[31m";
    public static final String _GREEN = "\u001B[32m";
    public static final String _YELLOW = "\u001B[33m";
    public static final String _BLUE = "\u001B[34m";
    public static final String _PURPLE = "\u001B[35m";
    public static final String _CYAN = "\u001B[36m";
    public static final String _WHITE = "\u001B[37m";
    public static final String _ORANGE = "\033[38;2;255;149;0m";

    public static final String _BOLD = "\033[1m";
    public static final String _UNDERLINE = "\033[1m";
    
    public static final String __BLACK = "\u001b[1;40m";
    public static final String __RED = "\u001B[41m";
    public static final String __GREEN = "\u001B[42m";
    public static final String __YELLOW = "\u001B[43m";
    public static final String __BLUE = "\u001B[44m";
    public static final String __PURPLE = "\u001B[45m";
    public static final String __CYAN = "\u001B[46m";
//    public static final String __ORANGE = "\u001B[48;5;202m";
    public static final String __ORANGE = "\033[48;2;255;149;0m";//"\001b[38;2;255;149;0m";
    public static final String __WHITE = "\u001B[47m";
    
    static public void clear(){//System.out.print("\033\143");
//	    System.out.print("\033[H\033[2J");  
//	    System.out.flush();
	    
//	    TODO: Find solution
	    String tempStr="";
	    for(int i=0; i<20; i++) {
	    	tempStr+="\n";
	    }
	    
//        try {
//			new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	    
	    System.out.println(tempStr);
    }
    
    
    static String propertyLine(Player player_, Property[] properties_) {
    	String tempStr = "";
    	char id = player_.getId();
    	for(Property property: properties_) {
    		if(id == property.owner())
//    			tempStr+=getFC(property.color())+"%"+_CLEAR;
    			tempStr+=__BLACK+getFC(property.color())+(property.name().substring(0,1))+_CLEAR;
    	}
    	return __BLACK+player_.getColor()+"<"+player_.getCharacter()+">"+_CLEAR+":"+__BLACK+" "+tempStr+__BLACK+" "+UI._CLEAR;
    }
    
    static public char getTypedChr(){
//    	return getTypedChr("");
    	
        try{
//          Runtime.getRuntime().exec(cmd1).waitFor();
      	char c = '\0';
          while(c == '\0'){
          	c = (char) System.in.read();
          }
//          Runtime.getRuntime().exec(cmd2).waitFor();
          
          System.out.print("\n");
//          c='e';
          return c;
      }catch(Exception e){System.out.println("e!!! = "+e);}
      return '\0';
      
    }
    
    static public char getTypedChr(String request_){
    	System.out.print(request_);
        try{
//            Runtime.getRuntime().exec(cmd1).waitFor();
        	char c = '\0';
            while(c == '\0'){
            	c = (char) System.in.read();
            }
//            Runtime.getRuntime().exec(cmd2).waitFor();
            
            System.out.print("\n");
//            c='e';
            return c;
        }catch(Exception e){System.out.println("e!!! = "+e);}
        return '\0';
    }
    
    static public String getTypedStr(){
        try{
            return new Scanner(System.in).next();
        }catch(Exception e){}
        return "";
    }
    static public String getTypedStr(String request_){
    	System.out.print(request_);
        try{
            return new Scanner(System.in).next();
        }catch(Exception e){}
        return "";
    }
    
    
//CONSTRUCTORS
    static public char[][][] setupBoard(){
//    								X   Y   C
    	char[][][] board = Creation.fromFile();
    	
    
    	
    	return board;
    }
    
    
    
    
    static public String prettyify(String board_) {
//    	for(int i=0; i<80;i++) {//I could reduce the number here
//    		board_.replace("S"+);
//    	}
    	
//    	CUSTOM
    	board_= board_.replace("S80","===");
    	board_= board_.replace("S81","===");
    	
    	
//    	board_= board_.replaceAll("S[0-9][0-9]", "   ");
    	board_= board_.replaceAll("S\\d\\d", "   ");
    	
//    	TODO: Use more optimized code from game framework project?
    	
    	board_ = board_.replace("p",__PURPLE+_BLACK+"="+_CLEAR);
    	board_ = board_.replace("c",__CYAN+_BLACK+"="+_CLEAR);
    	board_ = board_.replace("b",__BLUE+_BLACK+"="+_CLEAR);
    	board_ = board_.replace("y",__YELLOW+_BLACK+"="+_CLEAR);
    	board_ = board_.replace("g",__GREEN+_BLACK+"="+_CLEAR);
    	board_ = board_.replace("r",__RED+_BLACK+"="+_CLEAR);
    	board_ = board_.replace("B",__BLACK+_BLACK+"="+_CLEAR);
    	board_ = board_.replace("o",__ORANGE+_BLACK+"="+_CLEAR);
    	board_ = board_.replace("h",_RED+"%"+_CLEAR);

    	
    	return board_;
    }
    
    static public String getFC(char c_){
        switch (c_) {
            case '\0': //Null
            return _CLEAR;
            case 'C': //Clear
            return _CLEAR;
            case 'B': //Black
            return _BLACK;
            case 'r': //Red
            return _RED;
            case 'g': //Green
            return _GREEN;                           
            case 'y': //Yellow
            return _YELLOW;                           
            case 'b': //Blue
            return _BLUE;                           
            case 'p': //Purple
            return _PURPLE;                           
            case 'c': //Cyan
            return _CYAN;
            case 'W': //White
            return _WHITE;
            case 'o': //Orange
            return _ORANGE;
            default: return _CLEAR;
        }
    }
    
    static public String makeBoardStr(char[][][] board_) {
    	String returnStr = "";
//    	char c = '\0';
    	for(int y = 0; y < board_.length; y++) {//Y
        	for(int x = 0; x < board_[0].length; x++) {//X
//        		char test = board_[y][x][0];
//        		
//        		if(getF()) {
//        			
//        		}
        		
        		returnStr += board_[y][x][0];
        	}
        	returnStr+="\n";
    	}
    	returnStr+="\n";
    	return returnStr;
    }
  
    
    
    
    
    static public String displayScreen(String title_, String[] options_, boolean returnPos_){
        // char[][][] screen = new char[passClass_.BOARD_DIMENTIONS_XY[0]][passClass_.BOARD_DIMENTIONS_XY[1]][2];
        char[][][] screen = new char[20+2][60+2][2];
        char boarder = ' ';


        clear();

        for(int i = 0; i < screen.length; i++){//TOD: Make it more efficient
            for(int j = 0; j < screen[0].length; j++){
                screen[i][j][0] = '%';
            }
        }

        for(int i = 0; i < screen.length; i++){//TOD: Make it more efficient
            screen[i][0][0] = '█';
            screen[i][0][1] = 'g';}
        for(int i = 0; i < screen.length; i++){
            screen[i][screen[0].length-1][0] = '█';
            screen[i][screen[0].length-1][1] = 'g';}
        for(int i = 0; i < screen[0].length; i++){
            screen[0][i][0] = '█';
            screen[0][i][1] = 'g';}
        for(int i = 0; i < screen[0].length; i++){
            screen[screen.length-1][i][0] = '█';
            screen[screen.length-1][i][1] = 'g';}
        
        // TITLE
        int startingIndex = ((screen[0].length - title_.length()) / 2);
        for(int i = 0; i<title_.length(); i++){
            screen[3][startingIndex+i][0] = title_.charAt(i);
        }

        String[] optionsDisplay = new String[options_.length+1];
        optionsDisplay[0] = "%:OPTIONS:";
        for(int i = 1; i < optionsDisplay.length; i++){
            optionsDisplay[i] = "["+i+"] "+options_[i-1];
        }
        
        int startingIndexOptionsX = 5;
        int startingIndexOptionsY = 5;
        
        for(int h = 0; h<optionsDisplay.length; h++){
            for(int j = 0; j<optionsDisplay[h].length(); j++){//screen[0].length
                screen[startingIndexOptionsY+h*2][startingIndexOptionsX+j][0] = optionsDisplay[h].charAt(j);
            }
        }


        for(int i = 2; i < screen.length-1; i++){
            for(int j = 2; j < screen[0].length-1; j++){
                if(screen[i][j][0]!='%' && screen[i][j][0]!=boarder){
                    if(screen[i][j+1][0]=='%'){screen[i][j+1][0]=' ';}
                    if(screen[i][j-1][0]=='%'){screen[i][j-1][0]=' ';}
                    if(screen[i-1][j][0]=='%'){screen[i-1][j][0]=' ';}
                    if(screen[i+1][j][0]=='%'){screen[i+1][j][0]=' ';}
                }
                //Cleanup of corners
                if(screen[i][j-1][0]==boarder && screen[i-1][j-1][0]=='%' && screen[i+1][j-1][0]=='%'){
                    screen[i+1][j-1][0]=boarder;
                    screen[i-1][j-1][0]=boarder;                    
                }else if(screen[i][j-1][0]=='%' && screen[i-1][j-1][0]==boarder && screen[i][j][0]==boarder){
                    screen[i][j-1][0]=boarder;
                }else if(screen[i][j-1][0]=='%' && screen[i-1][j-1][0]==boarder && screen[i][j-2][0]==boarder){
                    screen[i][j-1][0]=boarder;
                }
            }
        }

        //Could be replaceall but there is not realy a need, this keeps it from looking after it finds the first as there is only one.
        String stringedScreen = toString(screen).replaceFirst(" \\[1\\]"," ["+__RED+"*"+_CLEAR+"]");
        
        char c = '\0';
        int pos = 1;//It was a mistake to deal with short
        while(c != 'e'){
            int lastPos = pos;
            clear();
            System.out.print(stringedScreen);
            System.out.print("Use the WS to move, E to select: ");
            c = Character.toLowerCase(getTypedChr());
                 if(c=='w' && pos > 1){pos--;}
            else if(c=='s' && pos < options_.length){pos++;}
            else if(Character.isDigit(c)){
                     if(Integer.valueOf(c)==0) pos = 1;
                else if(( Integer.valueOf(c+"")) > options_.length-1) pos = options_.length-1;
                   else pos = Integer.valueOf(c+"");
            }

            if(lastPos != pos){
                System.out.println("---");
                stringedScreen = stringedScreen.replace(" ["+__RED+"*"+_CLEAR+"]"," ["+lastPos+"]");
                stringedScreen = stringedScreen.replace(" ["+pos+"]"," ["+__RED+"*"+_CLEAR+"]");
//                clear();
                System.out.print(stringedScreen);
            }
        }
        if(returnPos_) {
            return pos+"";
        }else{
            return options_[pos-1];
        }
    }
    
    static public String toString(char[][][] screen_){
        String returnMe_="\033[4;32m";//"\033[4;33m";//"\u001B[43m";
        char c_ = screen_[0][0][0];
        char lastC_ = '\0';

        for(int i=0;i<screen_.length;i++){//ByRow
            for(int j=0;j<screen_[0].length;j++){//ByCollom
                c_ = screen_[i][j][1];
                if(c_ != lastC_){
                    lastC_ = c_;
                    switch (c_) {
                        case '\0': //Null
                        returnMe_+=_CLEAR;
                        break;
                        case 'C': //Clear
                        returnMe_+=_CLEAR;
                        break;
                        case 'B': //Black
                        returnMe_+=_BLACK;
                        break;
                        case 'r': //Red
                        returnMe_+=_RED;
                        break;
                        case 'g': //Green
                        returnMe_+=_GREEN;
                        break;                            
                        case 'y': //Yellow
                        returnMe_+=_YELLOW;
                        break;                            
                        case 'b': //Blue
                        returnMe_+=_BLUE;
                        break;                            
                        case 'p': //Purple
                        returnMe_+=_PURPLE;
                        break;                            
                        case 'c': //Cyan
                        returnMe_+=_CYAN;
                        break;
                        case 'W': //White
                        returnMe_+=_WHITE;
                        break;
                        
                        default: ;
                    }
                }
                returnMe_+=screen_[i][j][0];
            }
            returnMe_+='\n';
        }
        return returnMe_+_CLEAR;
    }
    
    
}