package com.company;

import java.util.Scanner;

public class UI{
    public final static String[] cmd1 = {"/bin/sh", "-c", "stty raw </dev/tty"};
    public final static String[] cmd2 = {"/bin/sh", "-c", "stty cooked </dev/tty"};

    static public char getTypedChr(){
        try{
            Runtime.getRuntime().exec(cmd1).waitFor();
            char c = (char) System.in.read();
            Runtime.getRuntime().exec(cmd2).waitFor();

            System.out.print("\n");
            return c;
        }catch(Exception e){}
        return '\0';
    }


    public static String ask(String askLine_){
        System.out.print(askLine_);
        return (new Scanner(System.in)).nextLine();
        // in.exit();
    }

    public static char askOptions(){
        System.out.print("\n"
        +"\n        Program: Custom HomeServer"        
        +"\n-------------------------------------------"
        +"\na - Run cycle (check emails)"
        +"\nA - Run cycles (check emails while on loop)"
        +"\ns - Sends an email with existing paramaters"
        +"\nD - Attempts to deleate all emails in all  "
        +"\n    folders defined in code"
        +"\n-------------------------------------------"
        +"\nPlease enter your choice: "
        );
        return getTypedChr();
    }


// switch (chosenChar) {
//             case '\0': //Null
//             chosenChar;
//             default: return Rules._CLEAR;
//         }

    static public void clear(){System.out.print("\033\143");}


// TIME/THREADS

    public static void tSleep(double seconds_){
        try{Thread.sleep(Double.valueOf(seconds_*1000).longValue());}
        catch(InterruptedException ex){
        Thread.currentThread().interrupt();}
    }

    public static void tSleepMil(double miliseconds_){
        try{Thread.sleep(Double.valueOf(miliseconds_).longValue());}
        catch(InterruptedException ex){
        Thread.currentThread().interrupt();}
    }

}