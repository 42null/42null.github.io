import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors
// import java.io.FileWriter;   // Import the FileWriter class
import java.util.Scanner; // Import the Scanner class to read text files

public class Creation{

	
	
	static public int generateDiceRoll(int sides_) {
		//Does not need a seed in this use case so Math.random will be used.
//		TODO: Make sure this is a fair roller.
//		return (int) (Math.round((Math.random() * sides_)))+1;//Is fair I believe but returns range+1
		return (int) (Math.round((Math.random() * (sides_-1))))+1;//TODO: Check fairness
	}
	
	
//	public static char[][][] fromFile(String directory_, String fileName_, boolean isOringal_){
	public static char[][][] fromFile(){
        char[][][] returnArray_ = new char[36][47][1];

        try{
//            File textFile = new File("H:\\EclipiseProjectFolder\\Monopoly\\src\\skeltonBoard.txt");
            File textFile = new File("D:\\Users\\memmjos\\Desktop\\Monopoly_06-04-2021_09^41\\src\\skeltonBoard.txt");
            
            Scanner myReader = new Scanner(textFile);

            String deconstruct = "";

            for(int i=0;i <returnArray_.length; i++){//ByRow
                deconstruct = myReader.nextLine();
                for(int j=0; j < deconstruct.length(); j++){
                    returnArray_[i][j][0] = deconstruct.charAt(j);
                }
            }
            // if(!nextLine.isEmpty()){
//            try{
//                // CHARACTER COLORS
//                if(myReader.nextLine().equals(".")){
//                    deconstruct = myReader.nextLine().replace(" ","");
//                    for(int i = 0; i < deconstruct.length(); i+=2){
//                        returnArray_ = setCharsColor(returnArray_, deconstruct.charAt(i),deconstruct.charAt(i+1));
//                    }
//                }
//                // CHARACTER REPLACEMENTS
//                if(myReader.nextLine().equals(".") && isOringal_){
//                    deconstruct = myReader.nextLine().replace(" ","");
//                    for(int i = 0; i < deconstruct.length(); i+=2){
//                        returnArray_ = replaceChars(returnArray_, deconstruct.charAt(i),deconstruct.charAt(i+1));
//                    }
//                }else{
//                    myReader.nextLine();
//                }
//            }catch(Exception e){
//                System.out.println("ERROR WITH CREATION FILE = "+e);
//            }

            myReader.close();
        }catch(Exception e){System.out.println("Error with Creation file :"+e);}
        return returnArray_;
    }


}