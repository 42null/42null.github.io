package com.company;/*
This project uses some code from...
    https://www.rgagnon.com/javadetails/java-receive-email-using-imap.html
*/

/*
TODO:
 - Make it listen instead of check all the time using javax.mail.event
Interface MessageCountListener
*/



import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.util.Properties;

import java.io.IOException;

import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

// import javax.mail.*;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.internet.*;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;


public class StartupEmailNotifier {

// VALUES
        private static final String USERNAME_MASTER = "";
        private static final String PASSWORD_MASTER = "";
        private static final String    TARGET_EMAIL = "";

//        private static final String URL_OF_IP_REQUEST_SERVICE = "http://bot.whatismyipaddress.com";
        private static final String[] SOME_PUBLIC_IPV4_URL_OPTIONS = {"https://ipv4bot.whatismyipaddress.com","https://ifconfig.me"};
        private static final String[] SOME_PUBLIC_IPV6_URL_OPTIONS = {"https://ipv6bot.whatismyipaddress.com"};

        private static final String PUBLIC_IPV4_CURL_URL = SOME_PUBLIC_IPV4_URL_OPTIONS[1];
        private static final String PUBLIC_IPV6_CURL_URL = SOME_PUBLIC_IPV6_URL_OPTIONS[0];

        private static final String               DEVICE_NAME = "Grandma pi3 router";// Will be used in the subject line
        private static final String CONSOLE_STARTING_PRINTOUT = "Displaying IP email report for "+DEVICE_NAME;

        private static final String    CUSTOM_COMMAND_TO_ECHO = "";

// REPORTING FLAGS
        private static final boolean FLAG_REPORT_DEFAULT_NETWORKING =  true; //Reports info on ips, hostnames, etc. Everything this project originally was created to do.
        private static final boolean     FLAG_REPORT_CUSTOM_COMMAND =  true; //Place your command line to execute here with an echo. The echo will be sent back in the email contents.

        private static final boolean      FLAG_REPORT_TO_CONSOLE = true;
        private static final boolean FLAG_PRINT_EMAIL_TO_CONSOLE = true;

// ITEMS TO INCLUDE IN EMAIL
        private static final boolean            FLAG_REPORT_IPV4 = true; /*IP*/
        private static final boolean            FLAG_REPORT_IPV6 = true; /*IP*/
        private static final boolean        FLAG_REPORT_LOCAL_IP = true; /*IP*/
        private static final boolean       FLAG_REPORT_GLOBAL_IP = true; /*IP*/
        private static final boolean        FLAG_REPORT_HOSTNAME = true; /*NAME*/

        String errorReport = "";
    public static void main(String[] args) throws UnknownHostException {
        System.out.println("Host addr: " + InetAddress.getLocalHost().getHostAddress());  // often returns "127.0.0.1"
//        String[] interface
        Enumeration<NetworkInterface> n = null;
        try {
            n = NetworkInterface.getNetworkInterfaces();
        } catch (SocketException e) {
            e.printStackTrace();
        }
//        for (; n.hasMoreElements();)
        if(true)
        {
            NetworkInterface e = n.nextElement();
//            System.out.println("Interface: " + e.getName());
            Enumeration<InetAddress> a = e.getInetAddresses();
//            for (; a.hasMoreElements();)
            if(true)
            {
                InetAddress addr = a.nextElement();
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~  " + addr.getHostAddress());
            }
        }




        System.out.println(CONSOLE_STARTING_PRINTOUT+"...");
        //IP's
        String localIPv4  = FLAG_REPORT_IPV4 && FLAG_REPORT_LOCAL_IP  ? getIPAddresses('l',4) : null;
        String globalIPv4 = FLAG_REPORT_IPV4 && FLAG_REPORT_GLOBAL_IP ? getIPAddresses('p',4) : null;
        String localIPv6  = FLAG_REPORT_IPV6 && FLAG_REPORT_LOCAL_IP  ? getIPAddresses('l',6) : null;
        String globalIPv6 = FLAG_REPORT_IPV6 && FLAG_REPORT_GLOBAL_IP ? getIPAddresses('p',6) : null;

        String hostname   = FLAG_REPORT_HOSTNAME && FLAG_REPORT_GLOBAL_IP ? getHostname() : null;
        String consoleReport = "";

        if(FLAG_REPORT_TO_CONSOLE){
            consoleReport += hostname.length()   != 0 ? ("Device Hostname: "+hostname+"\n")  : "";
            consoleReport += localIPv4.length()  != 0 ? ("Local IP -(V4)-: "+localIPv4+"\n") : "";
            consoleReport += localIPv6.length()  != 0 ? ("Local IP -(V6)-: "+localIPv6+"\n") : "";
            consoleReport += globalIPv4.length() != 0 ? ("Public IP (V4)-: "+globalIPv4+"\n"): "";
            consoleReport += globalIPv6.length() != 0 ? ("Public IP (V6)-: "+globalIPv6)     : "";
        }

        String emailSubject = "Startup IP UPDATE ["+DEVICE_NAME+"] - "+((FLAG_REPORT_IPV4? "IPV4":"") + ((FLAG_REPORT_IPV4&&FLAG_REPORT_IPV6)? " & ":"") + (FLAG_REPORT_IPV6? "IPV6":""));
        String emailContents =
             "Here is your ip email report for the device \'"+DEVICE_NAME+"\'."+"\n"
            +"---\n"
            +consoleReport+"\n"
            +"---\n"
            +"\n"
            +"This email was automatically generated and sent by the java program \'Startup Email Notifier\' built by 42Null (https://42null.memmojs.repl.co/)"+"\n"
//            +"The ip I reported came from \""+URL_OF_IP_REQUEST_SERVICE+"\""
            +"\nThis email was sent on "+(((DateTimeFormatter.ofPattern("EEEE, MMMM dd"))).format(LocalDateTime.now()))+" at "+(((DateTimeFormatter.ofPattern("HH:mm:ss"))).format(LocalDateTime.now()))
            +"\nTimestamp: "+(((DateTimeFormatter.ofPattern("MM/dd/yyy"))).format(LocalDateTime.now()))+" at "+(((DateTimeFormatter.ofPattern("HH:mm:ss"))).format(LocalDateTime.now()));
        ;

        System.out.println("Sending email...");
        if(FLAG_PRINT_EMAIL_TO_CONSOLE){
            System.out.println(
                "Subject: "+emailSubject+"\n"+
                "Contents: "+emailContents+"\n"
            );
        }
        sendEmailFromMainAccount(TARGET_EMAIL,emailSubject,emailContents);//,readIPFromFile());
    }

    /**
     * Connects to the server providing the ip report back.
     * @param ipTypeChoice_ choose 'p' for the global ip, 'l' for its local ip.
     * @param ipVersion_ choose 4 for the IPV4 address, 6 for the IPV6 address.
     * @return a string of the ip requested or an error message if syntax is invalid.
     * @throws UnknownHostException
     */

    private static String getIPAddresses(char ipTypeChoice_, int ipVersion_) throws UnknownHostException {
        // Contains some code directly from https://www.geeksforgeeks.org/java-program-find-ip-address-computer/

        String returnIP = "This is most likely because I don't have a ip of that version right now. :(";
        URL url = null;

        if(ipTypeChoice_ == 'l'){
            InetAddress localhost = InetAddress.getLocalHost();
//            System.out.println("System IP Address : " +
//                    (localhost.getHostAddress()).trim());

            // Find public IP address
            String systemipaddress = "";
            try {
                url = new URL("http://bot.whatismyipaddress.com");

                BufferedReader sc = new BufferedReader(new InputStreamReader(url.openStream()));

                // reads system IPAddress
                returnIP = sc.readLine().trim();
            }catch(MalformedURLException e){
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            InetAddress localhost2 = InetAddress.getLocalHost();
            System.out.println("System IP Address : " +
                    (localhost2.getHostAddress()).trim());
            returnIP = systemipaddress;

            InetAddress ia = InetAddress.getLocalHost();
            returnIP = ia.getHostAddress();
            
            System.out.println(returnIP);

        }else if(ipTypeChoice_ == 'p'){
            try{
                switch (ipVersion_) {
                    case 4:
                        url = new URL(PUBLIC_IPV4_CURL_URL);
                        break;
                    case 6:
                        url = new URL(PUBLIC_IPV6_CURL_URL);
                        break;
                    default:
                        url = null;//new URL(SOME_PUBLIC_IPV4_URL_OPTIONS[0]);
                }
            }catch(MalformedURLException e){
                e.printStackTrace();
            }
            // Get Ip from URL
            if(url != null){
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"))) {
                    returnIP = reader.readLine();
                } catch (IOException e) {
                    returnIP = "I ran into a IOException because my url did not work. "+returnIP;
                }
            }else{
                returnIP = "The url you game me to work with was \"null\".";
            }
        }else{
            returnIP = "Invalid ip choice, 'l' for local 'p' for public required.";
        }
        return returnIP;
    }

    /**
     * Gets the hostname locally and then returns it.
     * @return
     * @throws UnknownHostException
     */
    private static String getHostname() throws UnknownHostException {
        return String.valueOf(InetAddress.getLocalHost().getHostName());
    }


    public static void printParts(Object content) throws IOException, MessagingException{
        OutputStream out = null;
        InputStream in = null;
        try{
            if (content instanceof Multipart) {
                Multipart multi = ((Multipart)content);
                int parts = multi.getCount();
                for (int i=0; i < parts; i++) {
                MimeBodyPart part = (MimeBodyPart) multi.getBodyPart(i);
                if (part.getContent() instanceof Multipart) {
                    printParts(part.getContent());
                }
                else {
                    in = part.getInputStream();
                    int k;
                    while ((k = in.read()) != -1) {
                        System.out.print((char)k);
                    }
                }
                }
            }
        }
        finally {
        if (in != null) { in.close(); }
        if (out != null) { out.flush(); out.close(); }
        }
    }

    private static void sendEmailFromMainAccount(String to_, String subject_, String content_){
        sendEmail(USERNAME_MASTER, PASSWORD_MASTER, to_, subject_, content_);
    }

    private static void sendEmail(String from_, String password_, String to_, String subject_, String content_){

        // SETUP EMAIL
        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "465");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.socketFactory.port", "465");
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(USERNAME_MASTER, PASSWORD_MASTER);
                    }
                });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME_MASTER));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(to_)
            );
            message.setSubject(subject_);
            message.setText(content_);
            Transport.send(message);

            System.out.println("Email Sent Successfully");
            System.out.println("------------------------------------------");
            System.out.println("Sent From:____ "+from_);
            System.out.println("Sent To:______ "+to_);
            System.out.println("Subject:______ "+subject_);
            System.out.println("Contents (below):\n"+content_);
            System.out.println("------------------------------------------");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
