#javac com/company/Main.java com/company/UI.java -cp com/company/activation.jar -cp com/company/javax.mail.jar
java -cp .:com/company/activation.jar.:com/company/javax.mail.jar com.company.Main com/company/UI

