unzip ./Connect-four-game_10-11-2020.zip
clear
javac *.java
java -classpath ./ Main
read -p "Press enter to exit and clean up system"
rm *.class *.java